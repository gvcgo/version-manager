package install

/*
installs prequisite.
*/
